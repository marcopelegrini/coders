/**
 * Commons options overlay functions
 *
 * @author marcotulio
 */
(function(){
	
    coders.ns("coders.changeHosts.options").commons = {

		ctx: coders.changeHosts.applicationContext,
    };
})();
