pref("extensions.changeHosts.log", true);

pref("extensions.changeHosts.hosts-location", "");
pref("extensions.changeHosts.script-location", "");
pref("extensions.changeHosts.script-flag", false);
pref("extensions.changeHosts.script-sudo-flag", false);
pref("extensions.changeHosts.flush-dns-on-change", true);
pref("extensions.changeHosts.label-color", "#000000");
pref("extensions.changeHosts.definition-color", "#000000");
pref("extensions.changeHosts.show-icon-status", true);
pref("extensions.changeHosts.show-definition-name", true);
pref("extensions.changeHosts.configured", false);
pref("extensions.changeHosts.default-host-file-extension", ".hosts");
pref("extensions.changeHosts.view-parsed-hosts", false);
pref("extensions.changeHosts.log-level", "INFO");
pref("extensions.changeHosts.read-files-limit", 5000);

pref("browser.preferences.instantApply", true);